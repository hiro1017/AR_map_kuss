# Map with GeoAR

GeoAR.jsを用いたロケーションベースのwebARアプリです．スマートフォンのGPSを使って取得した現在地の座標にバーチャルなピンを配置します．それぞれのピンには名称などのデジタル情報を付加することができます．

![](https://i.imgur.com/dNlsZka.jpg)

- URL（スマートフォンでの動作推奨）
https://te260ku.github.io/geoar/

- 機能の詳細
https://qiita.com/te26/items/7b4315635668f127204b